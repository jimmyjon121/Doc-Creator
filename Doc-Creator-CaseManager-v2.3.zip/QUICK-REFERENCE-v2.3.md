# 🚀 Doc Creator v2.3 - Quick Reference

## 🔑 Login
- **Username**: `Doc121`
- **Password**: `FFA121`

## ⌨️ Keyboard Shortcuts
- **Ctrl+Enter** (Cmd+Enter on Mac) → Generate document instantly
- **Ctrl+Z** (Cmd+Z on Mac) → Undo last action
- **Ctrl+S** (Cmd+S on Mac) → Save to vault
- **Ctrl+P** (Cmd+P on Mac) → Print (when preview open)
- **ESC** → Close any open window

## 🆕 New Features in v2.3

### 🔒 Professional Name Validation
- ✅ Green check = Valid first name
- ❌ Red X = Invalid (has spaces/numbers)
- ⚠️ Yellow warning = Special characters
- Auto-capitalizes as you type

### ↶ Undo Function
- Made a mistake? Press **Ctrl+Z** to undo
- Works for: adding, removing, reordering, clearing programs

### 📄 Smart PDF Names
- Automatically named: `ClientName_Options_2025-09-29.pdf`
- No need to rename files manually

### ⭐ Frequently Used Programs
- Click the gold **"⭐ Frequently Used"** button
- Shows your top 10 most-used programs
- Builds automatically as you work

### 🗑️ Safe Clear All
- Asks "Clear 3 programs?" before clearing
- Can undo with Ctrl+Z if needed

## 📋 3-Click Workflow
1. **Generate Document** → Opens preview
2. **Print Document** → Opens print dialog
3. **Save as PDF** → Saves with smart name

## 🔧 Chrome Extension
1. Visit any program website
2. Click extension icon
3. Click "Extract & Add"
4. Data appears in Doc Creator automatically

## ⚡ Pro Tips
- Session timeout extended to 4 hours
- Loading spinners show when processing
- First name validation prevents PHI entry
- All data stored locally (HIPAA compliant)

---
**Version 2.3** | Family First Adolescent Services
